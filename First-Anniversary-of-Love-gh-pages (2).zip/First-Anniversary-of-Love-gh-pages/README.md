## A website for my girlfriend to memorize our first anniversary of love.

demo：[https://ain-crad.github.io/First-Anniversary-of-Love](https://ain-crad.github.io/First-Anniversary-of-Love)

文件目录：   
* css：css源码      
* js/date.js：显示恋爱时长  
* js/playImg.js：循环播放照片  
* js/stars.js：背景部分  
* js/typeWriter.js：模拟打字效果  
* music：背景音乐  
* pic：图片  
* index.html：html源码
